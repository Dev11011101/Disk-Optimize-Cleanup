from tkinter import *
import os
from tkinter import messagebox
root= Tk()
root.iconbitmap("icon\dfrgui.ico")
root.title('Disk Optimize & Cleanup')
root.resizable(False, False)
root.configure(background='white')
canvas1 = Canvas(root, bg='white', width = 300, height = 100)
canvas1.pack()
label1 = Label(bg='white', text="Choose an option")
canvas1.create_window(150, 25, window = label1)
def optimize():
    try:
        os.startfile('dfrgui.exe')
    except:
        messagebox.showerror('System Error', 'The disk optimization process cannot proceed because dfrgui.exe was not found. Reinstalling the program may fix this problem.')
button1 = Button(text='Optimize', bd=0.5, width=10, command=optimize)
canvas1.create_window(100, 75, window=button1)
def cleanup():
    try:
        os.startfile('cleanmgr.exe')
    except:
        messagebox.showerror('System Error', 'The disk cleanup process cannot proceed because cleanmgr.exe was not found. Reinstalling the program may fix this problem.')
button2 = Button(text='Cleanup', bd=0.5, width=10, command=cleanup)
canvas1.create_window(200, 75, window=button2)
root.mainloop()
